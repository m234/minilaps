package com.cg.laps.beans;

import java.time.LocalDate;

public class CustomerDetails {

	long applicationId; 
	String applicantName;
	LocalDate dateOfBirth;
	String maritalStatus; 
	long phoneNumber;
	long mobileNumber;
	int countOfDependents; 
	String emailId;
	
	//default Constructor
	public CustomerDetails() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized Constructor
	public CustomerDetails(long applicationId, String applicantName, LocalDate dateOfBirth, String maritalStatus,
			long phoneNumber, long mobileNumber, int countOfDependents, String emailId) {
		super();
		this.applicationId = applicationId;
		this.applicantName = applicantName;
		this.dateOfBirth = dateOfBirth;
		this.maritalStatus = maritalStatus;
		this.phoneNumber = phoneNumber;
		this.mobileNumber = mobileNumber;
		this.countOfDependents = countOfDependents;
		this.emailId = emailId;
	}
	
	//Getters & Setters
	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getCountOfDependents() {
		return countOfDependents;
	}

	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	//Generate to String
	@Override
	public String toString() {
		return "CustomerDetails [applicationId=" + applicationId + ", applicantName=" + applicantName + ", dateOfBirth="
				+ dateOfBirth + ", maritalStatus=" + maritalStatus + ", phoneNumber=" + phoneNumber + ", mobileNumber="
				+ mobileNumber + ", countOfDependents=" + countOfDependents + ", emailId=" + emailId + "]";
	}
	
}
