package com.cg.laps.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.beans.LoanProgramsOffered;
import com.cg.laps.exception.LAPSException;
import com.cg.laps.service.LAPSServicEImpl;
import com.cg.laps.service.LAPSService;


public class CustomerHome {
	
	Scanner sc = new Scanner(System.in);
	LAPSService lService=null;
	LoanApplication loanApp = null;
	CustomerDetails cd = null;
	
	public void customerMenu() throws LAPSException {
		
		lService = new LAPSServicEImpl();
		System.out.println("\n***********Welcome Customer***********");
		int c=0;
		
		while(c!=4)
		{
			System.out.println("Select Operation to be performed:");
			System.out.println("1)View all loan Programs \n"
					+ "2)View Application status by ID \n"
					+ "3)Apply for Loan \n"
					+ "4)Exit ");
			System.out.println("Enter your choice:");
			c=sc.nextInt();
			switch(c)
			{
				case 1:
					displayAllLoans();
					break;
				case 2:
					viewAppStatusByID();
					break;
				case 3:
					addLoan();
					break;
				/*case 4:updateLoan();
					break;*/
				case 4: 
					break;
				default:
					System.out.println("Wrong Choice");
					break;
			}
			
		}
	
	}
	
	//For viewing Application status of customer by ID
	private void viewAppStatusByID() throws LAPSException
	{
		System.out.println("Enter Your Application Id");
		int app_id=sc.nextInt();
		try {
			LoanApplication obj=lService.viewApplicationStatusById(app_id);
			System.out.println(obj);			
		}
		catch (LAPSException e) 
		{
			System.out.println("Problem in viewing application status"+e.getMessage());
		}
	}
	
	//For viewing all the loan programs offered
	private void displayAllLoans() throws LAPSException 
	{
		
		ArrayList<LoanProgramsOffered> loanList;
		try {		
	
			loanList=lService.viewLoanProgramOffered();
			
			for(LoanProgramsOffered l:loanList)
			{
				System.out.println(l);
			}
		} 
		catch (LAPSException e) 
		{
			System.out.println("Problem in displaying all Loans"+e.getMessage());
		}
	}
	
	// To apply for the Loan
	private void addLoan()
	{
		try
		{			
			LocalDate t =null;
			
			System.out.println("Enter the Loan Program you want to avail");
			String prog = sc.next();
			lService.validateLoanProgramName(prog);
			LoanProgramsOffered obj=lService.getLoanProgramByName(prog);
			
			System.out.println("Enter the amount of loan you wish to apply for");
			double amtLoan = sc.nextInt();
			
			double min=obj.getMinLoanAmount();
			double max=obj.getMaxLoanAmount();
			lService.validateLoanAmount(min, max, amtLoan);
			System.out.println("Enter your address");
			String address = sc.next();
			System.out.println("Enter your annual family Income");
			double income = sc.nextInt();
			System.out.println("Document proofs available");
			String document=obj.getProofsRequired();
			String docProof = sc.next();			
			System.out.println(document);
			lService.validateDocument(docProof,document);
			System.out.println("Enter the collateral against the loan");
			String guarentee = sc.next();
			System.out.println("Enter the value of the collateral");
			double guarenteeValue = sc.nextInt();
			
				
			loanApp = new LoanApplication(1, t, prog, amtLoan, address, income, docProof, guarentee, guarenteeValue, "abc", t);
			
			System.out.println("Enter your name");
			String name = sc.next();
			lService.validateCustName(name);
			
			System.out.println("Enter your date of the birth(dd-MM-yyyy)");
			String sdate = sc.next();
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate ldate = LocalDate.parse(sdate,format);	
			
			System.out.println("Enter your marital status");
			String maritalStatus = sc.next();
			System.out.println("Enter your phone number");
			long phNo = sc.nextInt();
			lService.validatePhoneNo(phNo);
			System.out.println("Enter your Mobile number");
			long mobNo = sc.nextInt();
			lService.validateMobileNo(mobNo);
			System.out.println("Enter the count of dependents");
			int dependents = sc.nextInt();
			System.out.println("Enter your email address");
			String email = sc.next();
			lService.validateEmailId(email);
			cd = new CustomerDetails(1,name,ldate,maritalStatus,phNo,mobNo,dependents,email);
			
			int data2 = lService.addLoanApplication(loanApp);
			int data1 = lService.addCustomerDetails(cd);			
			if(data1==1 && data2==1)
			{
				System.out.println("Application succesfully created");
			}
			else
			{
				System.out.println("error in application creation");
			}
		}
		catch(Exception e)
		{
			System.out.println("Problem in inserting the Loan data"+e.getMessage());
		}	
	
	}

}
