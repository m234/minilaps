package com.cg.laps.test;

import static org.junit.Assert.*;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import org.junit.Test;

import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.dao.LAPSDaoImpl;
import com.cg.laps.exception.LAPSException;
import com.cg.laps.service.LAPSServicEImpl;


public class LAPSTest {

	@Test
    public void loginAdminTest() throws LAPSException {

		LAPSServicEImpl lService=new LAPSServicEImpl();
		assertEquals(1, lService.login("Alia", "Alia","Admin"));
			
	} 
	@Test
    public void loginLADTest() throws LAPSException {

		LAPSServicEImpl lService=new LAPSServicEImpl();
		assertEquals(1, lService.login("Hruta", "Hruta","LAD"));
			
	}
	
	@Test
    public void viewApplicationStatusByIdTest() throws LAPSException, ParseException {
		LoanApplication la = null;
		LAPSDaoImpl lmdao=new LAPSDaoImpl();
		assertEquals(la,lmdao.viewApplicationStatusById(100));			
	}

	@Test
    public void addCustomerDetailsTest() throws LAPSException {

		CustomerDetails custDetails = null;
		
		//custDetails.setApplicationId(1);
		custDetails.setApplicantName("Swastika");
		custDetails.setDateOfBirth(LocalDate.now());
		custDetails.setMaritalStatus("single");
		custDetails.setPhoneNumber(12345678);
		custDetails.setMobileNumber(1234567890);
		custDetails.setCountOfDependents(3);
		custDetails.setEmailId("swastika21@gmail.com");
		LAPSServicEImpl lService=new LAPSServicEImpl();
		try{
			assertEquals(null, lService.addCustomerDetails(custDetails));
		}
		catch(NullPointerException e){
			System.out.println("success");
		}
	} 

}
