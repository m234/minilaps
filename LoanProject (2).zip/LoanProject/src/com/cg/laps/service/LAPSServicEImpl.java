package com.cg.laps.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.laps.beans.ApprovedLoans;
import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.beans.LoanProgramsOffered;
import com.cg.laps.dao.LAPSDao;
import com.cg.laps.dao.LAPSDaoImpl;
import com.cg.laps.exception.LAPSException;

public class LAPSServicEImpl implements LAPSService {

	LAPSDao ldao = null;
	
	public LAPSServicEImpl() {
		// TODO Auto-generated constructor stub
		ldao = new LAPSDaoImpl();
	}

	@Override
	public int login(String username, String password, String role) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.login(username, password, role);
	}

	@Override
	public ArrayList<LoanProgramsOffered> viewLoanProgramOffered() throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewLoanProgramOffered();
	}

	@Override
	public int addLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.addLoanProgram(loanPrograms);
	}

	@Override
	public int deleteLoanProgram(String programName) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.deleteLoanProgram(programName);
	}

	@Override
	public int updateLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.updateLoanProgram(loanPrograms);
	}

	@Override
	public ArrayList<LoanApplication> viewAcceptedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewAcceptedLoans();
	}

	@Override
	public ArrayList<LoanApplication> viewRejectedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewRejectedLoans();
	}

	@Override
	public ArrayList<ApprovedLoans> viewApprovedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewApprovedLoans();
	}

	@Override
	public int addCustomerDetails(CustomerDetails custDetails) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.addCustomerDetails(custDetails);
	}

	
	@Override
	public int addLoanApplication(LoanApplication loanApp) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.addLoanApplication(loanApp);
	}
	
	@Override
	public LoanApplication viewApplicationStatusById(int id) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewApplicationStatusById(id);
	}

	@Override
	public ArrayList<LoanApplication> viewApplicationByLoanProgram(String programName) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.viewApplicationByLoanProgram(programName);
	}

	@Override
	public int updateApplicationStatus(int appId, String newStatus, LocalDate date) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.updateApplicationStatus(appId, newStatus, date);
	}

	@Override
	public int setStatusAfterInterview(int appId, String newStatus) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.setStatusAfterInterview(appId, newStatus);
	}

	@Override
	public int addToApprovedLoan(ApprovedLoans ap) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.addToApprovedLoan(ap);
	}

	@Override
	public LoanProgramsOffered getLoanProgramByName(String loanName) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.getLoanProgramByName(loanName);
	}

	@Override
	public String getCustomerDetailsByAppId(int id) throws LAPSException {
		// TODO Auto-generated method stub
		return ldao.getCustomerDetailsByAppId(id);
	}

	@Override
	public boolean validateCustName(String ename) throws LAPSException 
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, ename))
			return true;
		else
		{
			throw new LAPSException("\nMaximum 20 characters allowed and start with capital letter only");
		}
	}
	@Override
	public boolean validatePhoneNo(long pno) throws LAPSException {
		String PhNo= Long.toString(pno);
		String numberPattern="[0-9]{8}";
		if(Pattern.matches(numberPattern, PhNo))
			return true;
		else
		{
			throw new LAPSException("\nPhone number should contain exactly 8 digits.");
		}
	}
	@Override
	public boolean validateMobileNo(long mno) throws LAPSException 
	{
		String mNo= Long.toString(mno);
		String numberPattern="[0-9]{10}";
		if(Pattern.matches(numberPattern, mNo))
			return true;
		else
		{
			throw new LAPSException("\nMobile number should contain exactly 10 digits.");
		}
	}
	@Override
	public boolean validateEmailId(String mailid) throws LAPSException
	{
		String namePattern="[a-z0-9_.]+@[a-z]+.[a-z]+";
		if(Pattern.matches(namePattern, mailid))
			return true;
		else
		{
			throw new LAPSException("\nEmail id is invalid.");
		}
	}
	@Override
	public boolean validateLoanProgramName(String ename) throws LAPSException 
	{
		//String namePattern="Program_[A-Z]{1}";
		String namePattern="p[0-9]";
		if(Pattern.matches(namePattern, ename))
			return true;
		else
		{
			throw new LAPSException("\nLoan Program Name should of patterm Program_X");
		}
	}
	
	@Override
	public boolean validateLoanAmount(double min,double max, double amount ) throws LAPSException 
	{
		
		if(amount>=min && amount<=max)
			return true;
		else
		{
			throw new LAPSException("\nLoan Amount should be within a valid range .");
		}
	}
	
	@Override
	public boolean validateDocument(String docProof, String document) throws LAPSException {
		if(docProof.equals(document))
			return true;
		else
		{
			throw new LAPSException("\n"+document+"is required.");
		}
	}


}
